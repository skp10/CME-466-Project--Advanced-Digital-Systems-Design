#!/usr/bin/env python3
import PCF8591 as ADC
import RPi.GPIO as GPIO
# Import paho library
import paho.mqtt.client as mqtt
import time
import math

DO = 17

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

warn_signal = ""

'''
This method receives and prints the received message of pc text received.
This method also signals on the type of warn message.
'''
def on_message(client, userdata, message):

	# PC text receive Condition
	if message.topic == "skp196_pc_text":
		b = str(message.payload.decode("utf-8"))
		print("--------------------\nmessage received:", b, "\n--------------------")
	
	# Warn light Condition
	elif message.topic == "skp196_pc_warn":
		msg = message.payload.decode("utf-8")
		print("-----------\n",msg, "\n-----------")

		global warn_signal
		warn_signal = msg

'''
This method turns on and off the warn led
'''
def warn_led_light():
	if warn_signal == "warn_on":
		GPIO.output(27, True)
		time.sleep(0.5)
		GPIO.output(27, False)
	else:
		GPIO.output(27, False)

'''
Initial setup function that runs once.
'''
def setup():
	ADC.setup(0x48)
	GPIO.setup(DO, GPIO.IN)

	# ------- GPIO pins for led flash -------
	GPIO.setup(27, GPIO.OUT)
	GPIO.setup(5, GPIO.OUT)
	
	GPIO.output(5, False) # Set the pin 5 to ground

	# ------- GPIO pins for Car Parking ---------
	GPIO.setup(21, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # slot1
	GPIO.setup(20, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # slot2
	GPIO.setup(16, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # slot3
	GPIO.setup(12, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # slot4
	GPIO.setup(25, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # slot5
	GPIO.setup(23, GPIO.OUT)

	GPIO.output(23, True) # Set the pin 5 to ground
	

'''
For Analog Temperature module(with DO)
x: tmp value
prints better if x == 1 and Too Hot! if x == 0
'''
def Print(x):
	if x == 1:
		print('')
		print('***********')
		print('* Better~ *')
		print('***********')
		print('')
	if x == 0:
		print('')
		print('************')
		print('* Too Hot! *')
		print('************')
		print('')

'''
The main loop of the code (the main code is found here)
'''
def loop():
	status = 1
	tmp = 1

	'''
	* Use public broker (List of different Brokers)
	* Please uncomment each broker declaration upon your need.
	'''
	# mqttBroker = "mqtt.eclipseprojects.io"
	# mqttBroker = "test.mosquitto.org"
	# mqttBroker = "broker.emqx.io"
	mqttBroker = "broker.hivemq.com" # public broker

	client = mqtt.Client("skp196_rpi") # my name of client
	client.connect(mqttBroker)

	while True:

		warn_led_light()

		# -------- Gets the adc value and converts to temperature in C ---------
		analogVal = ADC.read(0)
		Vr = 5 * float(analogVal) / 255
		Rt = 10000 * Vr / (5 - Vr)
		temp = 1/(((math.log(Rt / 10000)) / 3950) + (1 / (273.15+25)))
		temp = temp - 273.15
		# ----------------------------------------------------------------------

		# ------ Publish Sensor Data Message ---------------------------------------------------
		client.publish("skp196_rpi_display_sensor_data", "temperature = " + str(round(temp, 3)) + " C", qos=2, retain=True) # publishing the message of topic
		print('Published temperature = ', round(temp, 3), 'C')
		# --------------------------------------------------------------------------
		
		# ------- Publish Parking Slot data (occupied or unoccupied) ------------------------------------
		if GPIO.input(21): # slot 1
			client.publish("skp196_rpi_P_slot1", "1", qos=2, retain=True) # publishing the message of topic
		else:
			client.publish("skp196_rpi_P_slot1", "0", qos=2, retain=True) # publishing the message of topic
		
		if GPIO.input(20): # slot 2
			client.publish("skp196_rpi_P_slot2", "1", qos=2, retain=True) # publishing the message of topic
		else:
			client.publish("skp196_rpi_P_slot2", "0", qos=2, retain=True) # publishing the message of topic

		if GPIO.input(16): # slot 3
			client.publish("skp196_rpi_P_slot3", "1", qos=2, retain=True) # publishing the message of topic
		else:
			client.publish("skp196_rpi_P_slot3", "0", qos=2, retain=True) # publishing the message of topic
		
		if GPIO.input(12): # slot 4
			client.publish("skp196_rpi_P_slot4", "1", qos=2, retain=True) # publishing the message of topic
		else:
			client.publish("skp196_rpi_P_slot4", "0", qos=2, retain=True) # publishing the message of topic

		if GPIO.input(25): # slot 5
			client.publish("skp196_rpi_P_slot5", "1", qos=2, retain=True) # publishing the message of topic
		else:
			client.publish("skp196_rpi_P_slot5", "0", qos=2, retain=True) # publishing the message of topic

		time.sleep(0.1)
		# --------------------------------------------------------------------------

		# ------ Subscribe Text Sent ---------------------------------------------------
		client.loop_start()
		client.subscribe("skp196_pc_text") # topic in the args of the method
		client.on_message = on_message # call a function, on message

		# ------ Subscribe Led on/off (Warn Message) ---------------------------------------------------
		client.subscribe("skp196_pc_warn") # topic in the args of the method
		client.on_message = on_message # call a function, on message

		time.sleep(0.1)
		# ---------------------------------------------------------
		

		# For a threshold, uncomment one of the code for
		# which module you use. DONOT UNCOMMENT BOTH!
		#################################################
		# 1. For Analog Temperature module(with DO)
		tmp = GPIO.input(DO)
		#
		# 2. For Thermister module(with sig pin)
		# if temp > 33:
		# tmp = 0
		# elif temp < 31:
		# tmp = 1
		#################################################

		# condition that uses print for status
		if tmp != status:
			Print(tmp)
			status = tmp

		time.sleep(0.2) # delay of 0.2 sec


if __name__ == '__main__':
	try:
		setup()
		loop()
	except KeyboardInterrupt:
		pass	