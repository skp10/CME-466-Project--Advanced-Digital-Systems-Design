# Import paho library
import paho.mqtt.client as mqtt
import time

# use public broker, declaare obj
mqttBroker = "broker.hivemq.com" # public broker
client = mqtt.Client("skp196_publisher") # my name of client
client.connect(mqttBroker)

# publish a message
client.loop_start()
while True:
    msg = "Hello MQTT message..."
    client.publish("skp196_test", msg, qos=2, retain=True) # publishing the message of topic

    # Prints to the terminal
    print("Message Published:", msg)

    # Some delay of 2 sec
    time.sleep(2)
