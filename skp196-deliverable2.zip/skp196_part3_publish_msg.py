#!/usr/bin/env python3
import PCF8591 as ADC
import RPi.GPIO as GPIO
import time
import math
import paho.mqtt.client as mqtt

DO = 17

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

'''
Initial setup function that runs once.
'''
def setup():
	ADC.setup(0x48)
	GPIO.setup(DO, GPIO.IN)

	# GPIO pins for led flash
	GPIO.setup(27, GPIO.OUT)
	GPIO.setup(5, GPIO.OUT)

	# Set the pin 5 to ground
	GPIO.output(5, False)

'''
For Analog Temperature module(with DO)
x: tmp value
prints better if x == 1 and Too Hot! if x == 0
'''
def Print(x):
	if x == 1:
		print('')
		print('***********')
		print('* Better~ *')
		print('***********')
		print('')
	if x == 0:
		print('')
		print('************')
		print('* Too Hot! *')
		print('************')
		print('')

'''
The main loop of the code (the main code is found here)
'''
def loop():
	status = 1
	tmp = 1
	'''
	* Use public broker (List of different Brokers)
	* Please uncomment each broker declaration upon your need.
	'''
	mqttBroker = "broker.hivemq.com"
	# mqttBroker = "mqtt.eclipseprojects.io"
	# mqttBroker = "test.mosquitto.org"
	# mqttBroker = "broker.emqx.io"

	client = mqtt.Client("skp196_publisher")  # my name of client
	client.connect(mqttBroker)
	client.loop_start()

	while True:

		# -------- Gets the adc value and converts to temperature in C ---------
		analogVal = ADC.read(0)
		Vr = 5 * float(analogVal) / 255
		Rt = 10000 * Vr / (5 - Vr)
		temp = 1/(((math.log(Rt / 10000)) / 3950) + (1 / (273.15+25)))
		temp = temp - 273.15
		# ----------------------------------------------------------------------

		# ------ Publish Message ---------------------------------------------------
		client.publish("skp196_test", "temperature = " + str(temp) + "C", qos=2, retain=True)
		time.sleep(2)

		# --------------------------------------------------------------------------

		print('Published temperature = ', temp, 'C')

		# For a threshold, uncomment one of the code for
		# which module you use. DONOT UNCOMMENT BOTH!
		#################################################
		# 1. For Analog Temperature module(with DO)
		tmp = GPIO.input(DO)
		#
		# 2. For Thermister module(with sig pin)
		# if temp > 33:
		# tmp = 0
		# elif temp < 31:
		# tmp = 1
		#################################################

		# condition that uses print for status
		if tmp != status:
			Print(tmp)
			status = tmp

		time.sleep(0.2) # delay of 0.2 sec


if __name__ == '__main__':
	try:
		setup()
		loop()
	except KeyboardInterrupt:
		pass