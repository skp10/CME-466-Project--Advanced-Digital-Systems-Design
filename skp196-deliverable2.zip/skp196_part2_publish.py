# Import paho library
import paho.mqtt.client as mqtt
import time

from cryptography.fernet import Fernet


'''
 * Use public broker (List of different Brokers)
 * Please uncomment each broker declaration upon your need.
'''
mqttBroker = "broker.hivemq.com" # public broker
# mqttBroker = "mqtt.eclipseprojects.io"
# mqttBroker = "test.mosquitto.org"
# mqttBroker = "broker.emqx.io"

client = mqtt.Client("skp196_publisher") # my name of client
client.connect(mqttBroker)

client.loop_start()
# publish a message
while True:
    start_time = time.time() # start time in seconds
    msg = "Hello MQTT!" # message to be sent

    # ------------------ Encryption Code ----------------------
    cipher_key = Fernet.generate_key() # generates a cipher_key
    cipher = Fernet(cipher_key)

    encrypted_msg = cipher.encrypt(bytes(msg, "utf-8")) # encrypts the message

    # ----------------------------------------------------------

    # creates a packet of different message
    data = (bytes(str(start_time), "utf-8"), encrypted_msg, cipher_key)
    packet = b'\x00'.join(element for element in data)

    # publishes the packet of the topic
    client.publish("skp196_test", packet, qos=2, retain=True)
    
    print("\nencrypted message published:", encrypted_msg)

    time.sleep(2) # delay of 2 sec
