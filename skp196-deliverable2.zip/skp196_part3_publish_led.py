# Import paho library
import paho.mqtt.client as mqtt
import time

'''
 * Use public broker (List of different Brokers)
 * Please uncomment each broker declaration upon your need.
'''
mqttBroker = "broker.hivemq.com" # public broker
# mqttBroker = "mqtt.eclipseprojects.io"
# mqttBroker = "test.mosquitto.org"
# mqttBroker = "broker.emqx.io"

client = mqtt.Client("skp196_publisher") # my name of client
client.connect(mqttBroker)
client.loop_start()


# publish a message
while True:
    start_time = time.time() # start time in seconds

    user_input = input("Please Select LED on/off mode:")

    # ------------- Condition to pass the message to the receiver based on user selection -------------
    msg = ""
    if (user_input == "on"):
        msg = "LED_ON"
    else:
        msg = "LED_OFF"

    # -------------------------------------------------------------------------------------------------

    # publishes the packet of the topic
    client.publish("skp196_test", msg, qos=2, retain=True)
    
    print("message published:", msg)

    time.sleep(2) # delay of 2 sec
