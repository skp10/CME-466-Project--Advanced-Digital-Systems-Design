import RPi.GPIO as GPIO
import time
import paho.mqtt.client as mqtt

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

'''
This method Turns on/off the led based on the received message.
'''
def on_message(client, userdata, message):
	msg = message.payload.decode("utf-8")
	print(msg)

	if msg == "LED_ON":
		GPIO.output(27, True)
	else:
		GPIO.output(27, False)

'''
Initial setup function that runs once.
'''
def setup():

	# GPIO pins for led flash
	GPIO.setup(27, GPIO.OUT)
	GPIO.setup(5, GPIO.OUT)

	# Set the pin 5 to ground
	GPIO.output(5, False)

'''
The main loop of the code (the main code is found here)
'''
def loop():

	'''
	* Use public broker (List of different Brokers)
	* Please uncomment each broker declaration upon your need.
	'''
	mqttBroker = "broker.hivemq.com"
	# mqttBroker = "mqtt.eclipseprojects.io"
	# mqttBroker = "test.mosquitto.org"
	# mqttBroker = "broker.emqx.io"

	client = mqtt.Client("skp196_subscriber")  # my name of client
	client.connect(mqttBroker)

	# Subscribe to receive a message --------------------------------------

	client.subscribe("skp196_test")  # topic in the args of the method
	client.on_message = on_message  # call a function, on message
	client.loop_forever()
	# ---------------------------------------------------------------------

if __name__ == '__main__':
	try:
		setup()
		loop()
	except KeyboardInterrupt:
		pass