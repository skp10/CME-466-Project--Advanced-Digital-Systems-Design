# import paho library
import paho.mqtt.client as mqtt
import time

from cryptography.fernet import Fernet

'''
This method receives and prints the received message.
It also finds the latency (start_time - end_time)
'''
def on_message(client, userdata, message):
    messageList = message.payload.decode("utf-8").split("\x00")
    start_time = float(messageList[0])
    encrypted_msg = bytes(messageList[1], "utf-8")
    cipher_key = bytes(messageList[2], "utf-8")
    
    end_time = time.time() # gets the current time in sec

    # ------------------ decryption Code ----------------------
    cipher = Fernet(cipher_key)

    msg = cipher.decrypt(encrypted_msg) # decrypts the message received

    print("\nmessage received:", msg.decode("utf-8"))
    # ---------------------------------------------------------

    # prints the latency which is end_time - start_time
    print("latency:", round(end_time - start_time, 5), "sec\n--------------------------------------------------")
    
'''
 * Use public broker (List of different Brokers)
 * Please uncomment each broker declaration upon your need.
'''
mqttBroker = "broker.hivemq.com"
# mqttBroker = "mqtt.eclipseprojects.io"
# mqttBroker = "test.mosquitto.org"
# mqttBroker = "broker.emqx.io"

client = mqtt.Client("skp196_subscriber") # my name of client
client.connect(mqttBroker)

# Subscribe to receive a message

client.subscribe("skp196_test") # topic in the args of the method
client.on_message = on_message # call a function, on message
client.loop_forever()
