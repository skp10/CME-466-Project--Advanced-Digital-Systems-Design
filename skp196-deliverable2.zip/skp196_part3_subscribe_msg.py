# Import paho library
import paho.mqtt.client as mqtt
import time

'''
This method receives and prints the received message.
'''
def on_message(client, userdata, message):
	msg = message.payload.decode("utf-8")

	print("Message Received:", msg)

'''
 * Use public broker (List of different Brokers)
 * Please uncomment each broker declaration upon your need.
'''
mqttBroker = "broker.hivemq.com" # public broker
# mqttBroker = "mqtt.eclipseprojects.io"
# mqttBroker = "test.mosquitto.org"
# mqttBroker = "broker.emqx.io"

client = mqtt.Client("skp196_subscriber") # my name of client
client.connect(mqttBroker)

# Subscribe to receive a message
client.subscribe("skp196_test") # topic in the args of the method
client.on_message = on_message # call a function, on message
client.loop_forever()
