import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(11, GPIO.OUT)
GPIO.setup(29, GPIO.OUT)

while True:
    GPIO.output(11, True)
    GPIO.output(29, False)