#!/usr/bin/env python3
import PCF8591 as ADC
import RPi.GPIO as GPIO
import time
import math

DO = 17

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

def setup():
	ADC.setup(0x48)
	GPIO.setup(DO, GPIO.IN)
	
	# # for led flash
	GPIO.setup(27, GPIO.OUT)
	GPIO.setup(5, GPIO.OUT)

	# # for switch
	GPIO.setup(23, GPIO.OUT)
	GPIO.setup(24, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

	GPIO.output(23, True)

def Print(x):
	if x == 1:
		print ('')
		print ('***********')
		print ('* Better~ *')
		print ('***********')
		print ('')
	if x == 0:
		print ('')
		print ('************')
		print ('* Too Hot! *')
		print ('************')
		print ('')

def loop():
	status = 1
	tmp = 1

	sw_pressed = 0
	while True:
		analogVal = ADC.read(0)
		Vr = 5 * float(analogVal) / 255
		Rt = 10000 * Vr / (5 - Vr)
		temp = 1/(((math.log(Rt / 10000)) / 3950) + (1 / (273.15+25)))
		temp = temp - 273.15
		
		# print(GPIO.input(24))
		if GPIO.input(24): ## if switch pressed and gpio pin 11 detects it
			print ('temperature = ', temp, 'C')
			sw_pressed = 1
		else:
			if sw_pressed:
				GPIO.output(27, True)
				time.sleep(0.2)
				GPIO.output(27, False)
				time.sleep(0.2)
				GPIO.output(27, True)
				time.sleep(0.2)
				GPIO.output(27, False)
				time.sleep(0.2)
				sw_pressed = 0

		# For a threshold, uncomment one of the code for
		# which module you use. DONOT UNCOMMENT BOTH!
		#################################################
		# 1. For Analog Temperature module(with DO)
		tmp = GPIO.input(DO)
		# 
		# 2. For Thermister module(with sig pin)
		#if temp > 33:
		#	tmp = 0
		#elif temp < 31:
		#	tmp = 1
		#################################################

		if tmp != status:
			Print(tmp)
			status = tmp

		time.sleep(0.2)

if __name__ == '__main__':
	try:
		setup()
		loop()
	except KeyboardInterrupt: 
		pass	